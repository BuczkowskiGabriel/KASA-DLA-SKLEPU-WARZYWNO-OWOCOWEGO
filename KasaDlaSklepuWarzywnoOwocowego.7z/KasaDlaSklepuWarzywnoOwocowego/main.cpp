#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

int main()
{
    string nazwaProduktu;
    int kodZakupowy;
    double cena;
    int iloscSztuk;

    cout << "##################################" << endl;
    cout << "KASA DLA SKLEPU WARZYWNO OWOCOWEGO" << endl;
    cout << "##################################" << endl;

    fstream plik("Warzywa.txt", ios::in);

    if(!plik.good())
    {
        cout << "Plik nie istnieje!";
        exit(EXIT_FAILURE);
    }

    while(getline(plik >> ws, nazwaProduktu, ';') >> kodZakupowy >> cena >> iloscSztuk)
    {
        cout << endl;
        cout << "Nazwa Produktu: " << nazwaProduktu << endl;
        cout << "Kod Zakupu: " << kodZakupowy << endl;
        cout << "Cena: " << cena << " zl" << fixed << setprecision(2) << endl;
        cout << "Ilosc Sztuk: " << iloscSztuk <<  endl;
    }

    plik.close();

    cout << endl;
    cout << "Podaj kod zakupu: ";

    return EXIT_SUCCESS;
}
